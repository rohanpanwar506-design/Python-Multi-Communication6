import socket
import threading
import tkinter as tk
from tkinter import messagebox, scrolledtext, simpledialog

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 5000


class ChatClient:
    def __init__(self, root):
        self.root = root
        self.root.title("Group Communication System")
        self.root.geometry("650x500")
        self.root.minsize(450, 350)
        self.connection = None
        self.connected = False

        self.chat = scrolledtext.ScrolledText(
            root, state="disabled", wrap="word",
            font=("Arial", 11), padx=10, pady=10
        )
        self.chat.pack(fill="both", expand=True, padx=10, pady=10)

        bottom = tk.Frame(root)
        bottom.pack(fill="x", padx=10, pady=(0, 10))

        self.message_var = tk.StringVar()
        self.entry = tk.Entry(bottom, textvariable=self.message_var, font=("Arial", 11))
        self.entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.entry.bind("<Return>", lambda _event: self.send_message())

        self.send_button = tk.Button(bottom, text="Send", command=self.send_message)
        self.send_button.pack(side="right")

        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.connect_to_server()

    def display(self, message):
        self.chat.configure(state="normal")
        self.chat.insert("end", message)
        self.chat.see("end")
        self.chat.configure(state="disabled")

    def connect_to_server(self):
        try:
            self.connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.connection.connect((SERVER_HOST, SERVER_PORT))
            self.connected = True
            threading.Thread(target=self.receive_messages, daemon=True).start()
        except OSError as error:
            messagebox.showerror(
                "Connection error",
                f"Could not connect to the server.\nStart server.py first.\n\n{error}"
            )
            self.root.after(100, self.close)

    def receive_messages(self):
        while self.connected:
            try:
                data = self.connection.recv(4096)
                if not data:
                    break
                message = data.decode("utf-8", errors="replace")
                self.root.after(0, self.display, message)
            except OSError:
                break
        self.connected = False
        if self.root.winfo_exists():
            self.root.after(0, self.display, "\nDisconnected from server.\n")

    def send_message(self):
        message = self.message_var.get().strip()
        if not message:
            return
        if not self.connected:
            messagebox.showwarning("Not connected", "The server connection is not active.")
            return
        try:
            self.connection.sendall(message.encode("utf-8"))
            self.display(f"You: {message}\n")
            self.message_var.set("")
        except OSError as error:
            messagebox.showerror("Send error", str(error))

    def close(self):
        self.connected = False
        if self.connection:
            try:
                self.connection.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            self.connection.close()
        self.root.destroy()


if __name__ == "__main__":
    window = tk.Tk()
    app = ChatClient(window)
    window.mainloop()
