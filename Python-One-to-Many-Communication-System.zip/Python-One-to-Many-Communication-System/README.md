# Python One-to-Many Communication System

A beginner-friendly group messaging desktop project built with Python sockets, threading and Tkinter. A message sent by one connected user is broadcast to the other connected users through the server.

## Features
- Client-server communication using TCP sockets
- Multiple clients can connect to one server
- Messages are broadcast to connected clients
- Tkinter graphical chat window
- Separate server and client programs

## Requirements
- Python 3
- Tkinter (usually included with Python)
- No third-party Python packages required

## Run locally
1. Download or clone this repository.
2. Open a terminal in this folder.
3. Start the server:

   ```bash
   python server.py
   ```

4. Open another terminal and start a client:

   ```bash
   python client.py
   ```

5. Run `python client.py` again in another terminal to open another client window.
6. Send a message from one client. Other connected clients receive it.

On Windows, `py server.py` and `py client.py` may be used instead.

## Important notes
- The default server address is `127.0.0.1`, so the demo works on one computer.
- This is an educational prototype, not a secure production messaging service. It does not include user authentication, encryption, message persistence or moderation.
- Do not expose this prototype directly to the public internet.
- For a classroom demonstration on a trusted local network, the server and client host settings need to be configured for that network.

## Project structure
- `server.py` — accepts client connections and broadcasts messages
- `client.py` — Tkinter chat interface and message receiver
- `requirements.txt` — dependency note

## Learning outcomes
This project demonstrates TCP sockets, client-server architecture, multithreading, GUI programming and basic network communication.
