import socket
import threading

HOST = "127.0.0.1"   # Local computer only. For a trusted LAN demo, configure the server IP.
PORT = 5000

clients = []
clients_lock = threading.Lock()


def broadcast(message, sender=None):
    """Send a message to every connected client."""
    with clients_lock:
        current_clients = list(clients)

    dead_clients = []
    for client in current_clients:
        if client is sender:
            continue
        try:
            client.sendall(message.encode("utf-8"))
        except OSError:
            dead_clients.append(client)

    if dead_clients:
        with clients_lock:
            for client in dead_clients:
                if client in clients:
                    clients.remove(client)
                try:
                    client.close()
                except OSError:
                    pass


def handle_client(client, address):
    print(f"Connected: {address}")
    try:
        client.sendall("Connected to the group communication server.\n".encode("utf-8"))
        while True:
            data = client.recv(4096)
            if not data:
                break
            message = data.decode("utf-8", errors="replace").strip()
            if message:
                print(f"{address}: {message}")
                broadcast(f"{address[0]}: {message}\n", sender=client)
    except (ConnectionError, OSError):
        pass
    finally:
        with clients_lock:
            if client in clients:
                clients.remove(client)
        client.close()
        print(f"Disconnected: {address}")


def main():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen()
    print(f"Server listening on {HOST}:{PORT}")
    print("Press Ctrl+C to stop.")

    try:
        while True:
            client, address = server.accept()
            with clients_lock:
                clients.append(client)
            thread = threading.Thread(
                target=handle_client,
                args=(client, address),
                daemon=True
            )
            thread.start()
    except KeyboardInterrupt:
        print("\nStopping server...")
    finally:
        with clients_lock:
            current_clients = list(clients)
            clients.clear()
        for client in current_clients:
            try:
                client.close()
            except OSError:
                pass
        server.close()


if __name__ == "__main__":
    main()
